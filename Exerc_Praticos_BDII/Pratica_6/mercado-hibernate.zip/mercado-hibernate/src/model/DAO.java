package model;

import java.util.ArrayList;
import java.util.Iterator;
import org.hibernate.Session;
import org.hibernate.Transaction;

public abstract class DAO
{
    private Session sessao;
    private Transaction tr;
    private Iterator it;

    public DAO()
    {
        //Abrir sessao
        sessao = HibernateUtil.getSessionFactory().openSession();
    }
    
    public void encerrarSessao()
    {
        sessao.close();
    }
   //-------------------------------- PRODUTOS--------------------------------
    public boolean CadastrarProduto(Produtos p)
    {
        sessao.save(p);
        tr = sessao.beginTransaction();
        tr.commit();
        
        //Se deu errado retorna falso
        return tr.wasCommitted();
    }
    
    public boolean deletarProduto(int codigo)
    {
        Produtos p;
        
        //Buscar o produto p no banco
        it = sessao.createQuery("from Produtos where codigo = "+codigo).list().iterator();
        if(it.hasNext())
        {
            p = (Produtos) it.next();
            sessao.delete(p);
            tr = sessao.beginTransaction();
            tr.commit();
            
            return tr.wasCommitted();
        }
        
        //Produto nao encontrado pelo codigo
        return false;
    }
    
    public Produtos buscaProduto(int codigo)
    {
        it = sessao.createQuery("from Produtos where codigo = "+codigo).list().iterator();
        
        if(it.hasNext())
            return (Produtos) it.next();
        
        return null;
    }
    
    public boolean atualizarProduto(Produtos p)
    {
        sessao.update(p);
        tr = sessao.beginTransaction();
        tr.commit();
        
        return tr.wasCommitted();
    }
    
    public ArrayList<Produtos> listarProdutos()
    {
        ArrayList<Produtos> produtos = new ArrayList();
        
        it = sessao.createQuery("from Produtos").list().iterator();
        
        while(it.hasNext())
        {
            produtos.add((Produtos) it.next());
        }
        
        return produtos;
    }
    
    //---------------------------------VENDAS-------------------------------
    public boolean cadastrarVenda(Vendas v)
    {
        sessao.save(v);
        tr = sessao.beginTransaction();
        tr.commit();
        
        //Se deu errado retorna falso
        return tr.wasCommitted();
    }
    
    public Vendas buscaVenda(int codigo)
    {
        Vendas v = null;
        //Buscar a venda p no banco
        it = sessao.createQuery("from Vendas where codigo = "+codigo).list().iterator();
        if(it.hasNext())
            v = (Vendas) it.next();
        
        return v;
    }
    
    public boolean atualizarVenda(Vendas v)
    {
        try{
            sessao.update(v);
        }catch(Exception exc){
            return false;
        }
        
        tr = sessao.beginTransaction();
        tr.commit();
        
        return tr.wasCommitted();
    }
    
    public boolean deletarVenda(int codigo)
    {
        Vendas v;
        //Buscar a venda p no banco
        it = sessao.createQuery("from Vendas where codigo = "+codigo).list().iterator();
        if(it.hasNext())
        {
            v = (Vendas) it.next();
            sessao.delete(v);
            tr = sessao.beginTransaction();
            tr.commit();
            
            return tr.wasCommitted();
        }
        
        //Venda nao encontrado pelo codigo
        return false;
    }
    
    public ArrayList<Vendas> listarVendas()
    {
        ArrayList<Vendas> vendas = new ArrayList();
        
        Iterator it = sessao.createQuery("from Vendas").list().iterator();
        
        while(it.hasNext())
        {
            vendas.add((Vendas) it.next());
        }
        
        return vendas;
    }
    //-----------------------------------ITENS DE VENDA----------------------
    public boolean cadastrarItemVenda(ItensVenda it)
    {
        sessao.save(it);
        tr = sessao.beginTransaction();
        tr.commit();
        
        return tr.wasCommitted();
    }
    
    public ArrayList<ItensVenda> visualizarItensVenda()
    {
        ArrayList<ItensVenda> itens = new ArrayList<>();
        
        Iterator it = sessao.createQuery("from ItensVenda").list().iterator();
        
        while(it.hasNext())
        {
            itens.add((ItensVenda) it.next());
        }
        
        return itens;
    }
    
    public boolean atualizarItemVenda(ItensVenda id)
    {
        sessao.update(id);
        tr = sessao.beginTransaction();
        tr.commit();
        
        return tr.wasCommitted();
    }
}
