
import Control.ControlePrincipal;

public class Application
{
    public static void main(String[] args) 
    {
         ControlePrincipal objCtrl = new ControlePrincipal();
         System.exit(0);
    }
}
