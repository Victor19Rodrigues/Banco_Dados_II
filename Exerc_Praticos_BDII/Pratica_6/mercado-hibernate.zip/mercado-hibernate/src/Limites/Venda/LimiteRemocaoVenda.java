/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Limites.Venda;

import java.util.Scanner;

/**
 *
 * @author mateus
 */
public class LimiteRemocaoVenda
{
    private Scanner teclado;
    private int codigo;

    public LimiteRemocaoVenda()
    {
        teclado = new Scanner(System.in);
        
        System.out.print("Informe o codigo da Venda: ");
        codigo = teclado.nextInt();
    }
    
    public int getCodigo()
    {
        return codigo;
    }
    
    public void mensagemSucesso()
    {
        System.out.println("[INFO]: VENDA REMOVIDA COM SUCESSO...");
    }
    
    public void mensagemErro()
    {
        System.out.println("[ERRO]: FALHA NA REMOCAO DO PRODUTO...");
    }
}
