/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Limites.Venda;

import java.util.Scanner;

/**
 *
 * @author mateus
 */
public class LimiteSubMenuVendas
{
    Scanner teclado;
    int choice;

    public LimiteSubMenuVendas()
    {
        teclado = new Scanner(System.in);
        choice = -7;
    }
    
    public int getEscolha()
    {
        System.out.println("\n\n:::::::.. MENU DE OPÇOES PARA VENDAS..:::::::\n");
        System.out.println("1. Cadastrar venda");
        System.out.println("2. Listar vendas cadastrados");
        System.out.println("3. Remover venda");
        System.out.println("4. Atualizar dados de venda");
        System.out.println("0. MENU PRINCIPAL\n");
        
        choice = -1;
        do{
            System.out.print("-> Informe o numero da opcao desejada.: ");
            choice = teclado.nextInt();
        }while(choice<0 && choice>4);
        
        return choice;
    }
    
}
