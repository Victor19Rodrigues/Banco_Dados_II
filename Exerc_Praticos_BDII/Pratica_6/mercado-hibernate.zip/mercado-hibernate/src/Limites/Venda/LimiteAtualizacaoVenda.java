/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Limites.Venda;

import java.util.Scanner;

/**
 *
 * @author mateus
 */
public class LimiteAtualizacaoVenda
{
    private Scanner teclado;
    private String data;
    private int codigo;
    private double valorTotal;
    private String cpfVendedor;

    public LimiteAtualizacaoVenda() 
    {
        teclado = new Scanner(System.in);
        
        System.out.print("Informe o codigo da venda: ");
        codigo = teclado.nextInt();
    }
    
    public int obterCodigo()
    {
        return codigo;
    }
    
    //primeiro campo :codigo
    //segundo: data
    //terceiro: valortotal
    //quarto: cpfvendedor
    public String[] obterDados(String[] aDadosForm)
    {
        String obj;
        
        System.out.print("\nVoce deseja atualizar a data? [s/n]");
        obj = teclado.next();        
        if(obj.equalsIgnoreCase("s"))
        {
            System.out.print("Informe a data no formato [dd/mm/aaaa]: ");
            data = teclado.next();
            aDadosForm[1] = data;
        }
        
        System.out.print("Voce deseja atualizar o valor total? [s/n]");
        obj = teclado.next();        
        if(obj.equalsIgnoreCase("s"))
        {
            System.out.print("Informe o valor total do produto: ");
            valorTotal = teclado.nextDouble();
            aDadosForm[2] = ""+valorTotal;
        }

        System.out.print("Voce deseja atualizar o cpf do vendedor? [s/n]");
        obj = teclado.next();        
        if(obj.equalsIgnoreCase("s"))
        {
            System.out.print("Informe o cpf do vendedor: ");
            cpfVendedor = teclado.next();
            aDadosForm[3] = cpfVendedor;
        }
        
        return aDadosForm;
    }
    
    public void mensagemErro()
    {
        System.out.println("[ERRO]: FALHA NA ATUALIZACAO DA VENDA...");
    }
    
    public void mensagemSucesso()
    {
        System.out.println("[INFO]: VENDA ATUALIZADA...");
    }
}
