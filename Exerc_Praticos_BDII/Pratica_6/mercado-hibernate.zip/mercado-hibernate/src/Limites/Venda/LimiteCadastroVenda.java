package Limites.Venda;

import java.util.Scanner;

/**
 *
 * @author mateus
 */
public class LimiteCadastroVenda
{
    private Scanner teclado;
     private String data;
     private double valorTotal;
     private String cpfVendedor;

    public LimiteCadastroVenda()
    {
        teclado = new Scanner(System.in);
        
        System.out.print("Iforme a data da venda no formado [dd/mm/aaaa]: ");
        data = teclado.next();
        System.out.print("Informe o cpf do vendedor: ");
        cpfVendedor = teclado.next();
        System.out.print("Informe o valor total: ");
        valorTotal = teclado.nextDouble();
    }
    
    public String[] obterDados()
    {
        String aDadosForm[] = new String[3];
        
        aDadosForm[0] = ""+data;
        aDadosForm[1] = ""+valorTotal;
        aDadosForm[2] = ""+cpfVendedor;
        
        return aDadosForm;
    }
    
    public void mensagemSucesso()
    {
        System.out.println("[INFO]: VENDA CADASTRADA COM SUCESSO");
    }
    
    public void mensagemErro()
    {
        System.out.println("[ERRO]: FALHA NO CADASTRO DA VENDA...");
    }
}
