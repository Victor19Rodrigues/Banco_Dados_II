package Limites.Venda;

import java.util.ArrayList;

public class LimiteExibicaoVendas
{

    public LimiteExibicaoVendas(ArrayList<String[]> vendas)
    {
        System.out.printf("\n%3s | %10s | %6s | %s\n", "COD","   DATA  ","VAL","CPF VEND.");
        System.out.println("---------------------------------------");
        for( String s[] : vendas)
        {
            System.out.printf("%3s | %10s | %6s | %s\n", s[0],s[1],s[2],s[3]);
        }
    }
    
}
