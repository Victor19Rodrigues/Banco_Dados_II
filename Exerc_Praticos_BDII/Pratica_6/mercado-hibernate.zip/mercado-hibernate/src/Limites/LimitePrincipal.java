package Limites;

import java.util.Scanner;

public class LimitePrincipal
{
    Scanner teclado;
    int choice;

    public LimitePrincipal()
    {
        teclado = new Scanner(System.in);
        choice = -7;
    }
    
    public int getEscolha()
    {
        System.out.println("\n\n:::::::::::.. MENU PRINCIPAL - MERCADO CAMAVI ..:::::::::::\n\n");
        System.out.println("1. Menu de produtos");
        System.out.println("2. Menu de vendas");
        System.out.println("3. Menu de itens de venda");
        System.out.println("0. SAIR DO SISTEMA\n");
        
        do
        {
            System.out.print("-> Informe o numero da opcao desejada: ");
            choice = teclado.nextInt();
        }while(choice<0 && choice>3);
        
        return choice;
    }
}
