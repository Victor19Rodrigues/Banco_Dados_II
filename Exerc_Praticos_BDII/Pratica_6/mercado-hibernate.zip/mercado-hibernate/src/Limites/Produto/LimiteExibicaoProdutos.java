package Limites.Produto;

import java.util.ArrayList;

public class LimiteExibicaoProdutos
{

    public LimiteExibicaoProdutos(ArrayList<String[]> produtos)
    {
        System.out.printf(" %3s | %30s | %4s | %s\n", "COD","NOME","QUANT","PRECO");
        System.out.println("---------------------------------------------------");
        
        for(String prod[] : produtos)
        {
            System.out.printf(" %3s | %30s | %4s | %s\n",prod[0],prod[1],prod[2],prod[3]);
        }
    }
    
}
