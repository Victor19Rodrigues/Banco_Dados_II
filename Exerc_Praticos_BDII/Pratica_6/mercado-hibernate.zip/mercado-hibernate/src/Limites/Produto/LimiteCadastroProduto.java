package Limites.Produto;

import java.util.Scanner;

public class LimiteCadastroProduto
{
    private Scanner teclado;
    private int qtdestoque;
    private String nome;
    private double preco;
    
    public LimiteCadastroProduto()
    {
        teclado = new Scanner(System.in);
        
        System.out.print("Informe o nome do produto: ");
        nome = teclado.nextLine();
        System.out.print("Informe a quantidade do produto em estoque: ");
        qtdestoque = teclado.nextInt();
        System.out.print("Informe o preço do produto: ");
        preco = teclado.nextDouble();
    }
    
    public String[] getDados()
    {
        String aDadosForm[] = new String[3];
        
        aDadosForm[0] = nome;
        aDadosForm[1] = ""+qtdestoque;
        aDadosForm[2] = ""+preco;
        
        return aDadosForm;
    }
    
    public void mensagemErro()
    {
        System.out.println("\n[ERRO]: FALHA AO CADASTRAR...");
    }
    
    public void mensagemSucesso()
    {
        System.out.println("\n[INFO]: PRODUTO CADASTRADO...");
    }
}
