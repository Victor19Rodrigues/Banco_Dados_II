/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Limites.Produto;

import java.util.Scanner;

public class LimiteRemocaoProduto
{
    private Scanner teclado;
    private int codigo;
    
    public LimiteRemocaoProduto()
    {
        teclado = new Scanner(System.in);
        
        System.out.print("Informe o codigo do produto: ");
        codigo = teclado.nextInt();
    }
    
    public String getCodigo()
    {
        return ""+codigo;
    }
    
    public void mensagemSucesso()
    {
        System.out.println("\n[INFO]: PRODUTO REMOVIDO...");
    }
    
    public void mensagemErro()
    {
        System.out.println("\n[ERRO]: FALHA AO REMOVER...");
    }
    
}
