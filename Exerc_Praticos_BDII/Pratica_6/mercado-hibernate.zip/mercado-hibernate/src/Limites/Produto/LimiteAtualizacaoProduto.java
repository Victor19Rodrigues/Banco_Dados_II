package Limites.Produto;

import java.util.Scanner;

public class LimiteAtualizacaoProduto
{
    private Scanner teclado;
    private int codigo,qtdestoque;
    private String nome;
    private double preco;
    
    public LimiteAtualizacaoProduto()
    {
        teclado = new Scanner(System.in);
        
        System.out.println("\nInforme o codigo do produto: ");
        codigo = teclado.nextInt();    
    }
    
    public int getCodigo()
    {
        return codigo;
    }
    
    public String[] obterDadosNovos(String form[])
    {
        String obj;
        
        System.out.print("Voce deseja atualizar o nome? [s/n]");
        obj = teclado.nextLine();        
        if(obj.equalsIgnoreCase("s"))
        {
            System.out.print("Informe o nome do produto: ");
            nome = teclado.next();
            form[1] = nome;
        }
        
        System.out.print("Voce deseja atualizar a quantidade em estoque? [s/n]");
        obj = teclado.next();
        if(obj.equalsIgnoreCase("s"))
        {
            System.out.print("Informe a nova quantidade estocada: ");
            qtdestoque = teclado.nextInt();
            form[2] = ""+qtdestoque;
        }

        System.out.print("Voce deseja atualizar o preço? [s/n]");
        obj = teclado.next();        
        if(obj.equalsIgnoreCase("s"))
        {
            System.out.print("Informe o preço do produto: ");
            preco = teclado.nextDouble();
            form[3] = ""+preco;
        }
        
        return form;
    }
    
    public void mensagemSucesso()
    {
        System.out.println("\n[INFO]: PRODUTO ATUALIZADO...");
    }
    
    public void mensagemErro()
    {
        System.out.println("\n[ERRO]: FALHA NA ATUALIZACAO DO PRODUTO...");
    }
}
