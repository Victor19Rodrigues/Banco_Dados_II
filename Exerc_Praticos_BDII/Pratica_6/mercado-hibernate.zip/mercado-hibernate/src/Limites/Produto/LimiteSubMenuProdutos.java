package Limites.Produto;

import java.util.Scanner;

public class LimiteSubMenuProdutos
{
    int choice;
    Scanner teclado;

    public LimiteSubMenuProdutos()
    {
        teclado = new Scanner(System.in);
    }
    
    public int getEscolha()
    {
        System.out.println("\n\n:::::::.. MENU DE OPÇOES PARA PRODUTOS..:::::::\n");
        System.out.println("1. Cadastrar produto");
        System.out.println("2. Listar produtos cadastrados");
        System.out.println("3. Remover produto");
        System.out.println("4. Atualizar dados de produto");
        System.out.println("0. MENU PRINCIPAL\n");
        
        choice = -1;
        do{
            System.out.print("-> Informe o numero da opcao desejada.: ");
            choice = teclado.nextInt();
        }while(choice<0 && choice>4);
        
        return choice;
    }
}
