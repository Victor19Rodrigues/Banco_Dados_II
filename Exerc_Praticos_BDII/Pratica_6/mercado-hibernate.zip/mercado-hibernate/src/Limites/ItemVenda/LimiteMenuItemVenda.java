package Limites.ItemVenda;

import java.util.Scanner;

public class LimiteMenuItemVenda
{
    Scanner teclado;
    int choice;

    public LimiteMenuItemVenda()
    {
        teclado = new Scanner(System.in);
    }
    
    public int obterEscolha()
    {
        System.out.println("\n\n:::::::.. MENU DE OPÇOES PARA ITENS DE VENDA..:::::::\n");
        System.out.println("1. Cadastrar item de venda");
        System.out.println("2. Listar itens cadastrados");
        System.out.println("3. Atualizar quantidade de item de venda");
        System.out.println("0. MENU PRINCIPAL\n");
        
        choice = -1;
        do{
            System.out.print("-> Informe o numero da opcao desejada.: ");
            choice = teclado.nextInt();
        }while(choice<0 && choice>3);
        
        return choice;
    }
    
}
