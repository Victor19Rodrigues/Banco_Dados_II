package Limites.ItemVenda;

import java.util.Scanner;

public class LimiteAtualizacaoItemVenda
{
    int codproduto,codvenda,quantidade;
    Scanner teclado;

    public LimiteAtualizacaoItemVenda()
    {
        teclado  = new Scanner(System.in);
        
        System.out.print("Informe o codigo do produto: ");
        codproduto = teclado.nextInt();
        System.out.print("Informe o codigo da venda: ");
        codvenda = teclado.nextInt();
    }
    
    public int[] obterIdentificador()
    {
        int vet[] = {codproduto,codvenda};
        
        return vet;
    }
    
    public int obterNovaQuantidade()
    {
        System.out.print("Informe a nova quantidade: ");
        quantidade = teclado.nextInt();
        
        return quantidade;
    }
    
    public void mensagemErro()
    {
        System.out.println("\n[ERRO]: FALHA AO ATUALIZAR ITEM DE VENDA...");
    }
    
    public void mensagemSucesso()
    {
        System.out.println("\n[INFO]: ITEM DE VENDA ATUALIZADO COM SUCESSO...");
    }
    
}
