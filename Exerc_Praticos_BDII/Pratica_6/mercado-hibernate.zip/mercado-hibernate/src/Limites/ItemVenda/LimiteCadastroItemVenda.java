package Limites.ItemVenda;

import java.util.Scanner;

public class LimiteCadastroItemVenda
{
    int codproduto,codvenda,quantidade;
    Scanner teclado;

    public LimiteCadastroItemVenda()
    {
        teclado = new Scanner(System.in);
        
        System.out.print("Informe o codigo do produto: ");
        codproduto = teclado.nextInt();
        System.out.print("Informe o codigo da venda: ");
        codvenda = teclado.nextInt();
        System.out.print("Informe a quantidade: ");
        quantidade = teclado.nextInt();
    }
    
    public int[] obterDados()
    {
        int vet[] = {codproduto,codvenda,quantidade};
        
        return vet;
    }
    
    public void mensagemSucesso()
    {
        System.out.println("[INFO]: ITEM DE VENDA CADASTRADO...");
    }
    
    public void mensagemErro()
    {
        System.out.println("[ERRO]: FALHA AO CADASTRAR ITEM DE VENDA...");
    }
}
