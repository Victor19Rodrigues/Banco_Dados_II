package Limites.ItemVenda;

public class LimiteVisualizacaoItemVenda
{

    public LimiteVisualizacaoItemVenda(int mat[][],int lin,int col)
    {
        System.out.println("COD PROD | COD VEN | QUANT");
        System.out.println("--------------------------");
        
        for(int i=0 ; i<lin ; i++)
        {
            System.out.printf("%7d | %7d | %3d\n", mat[i][0],mat[i][1],mat[i][2]);
        }
    }
    
}
