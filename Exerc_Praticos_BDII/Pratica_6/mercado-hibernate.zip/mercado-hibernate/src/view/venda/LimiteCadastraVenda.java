package view.venda;

public class LimiteCadastraVenda
{
    
}
