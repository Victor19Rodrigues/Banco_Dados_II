package Control;


import Limites.Venda.*;
import java.util.ArrayList;
import java.util.Date;
import model.*;
/**
 *
 * @author mateus
 */
public class ControleVendas extends DAO
{
    private Vendas v1;
    private LimiteCadastroVenda limcad;
    private LimiteRemocaoVenda limdel;
    private LimiteAtualizacaoVenda limatt;
    private LimiteExibicaoVendas limvis;
    private LimiteSubMenuVendas limsub;
    
    //Metodo construtor
    public ControleVendas()
    {
        v1 = null;
    }
    
    public void menuOpcoes()
    {
        limsub = new LimiteSubMenuVendas();
        int esc = limsub.getEscolha();
        
        while(esc != 0)
        {
            switch(esc)
            {
                case 1:
                    cadastrarVenda();
                    break;
                case 2:
                    exibirVendas();
                    break;
                case 3:
                    removerVenda();
                    break;
                case 4:
                    atualizarVenda();
                    break;
            }
            
            esc = limsub.getEscolha();
        }
    }
    
    //Metodo que cadastra uma venda no BD
    public void cadastrarVenda()
    {
        limcad = new LimiteCadastroVenda();
        
        String form[] = limcad.obterDados();
        Vendas v = new Vendas(converteData(form[0]),Double.parseDouble(form[1]),form[2]);
        boolean res = cadastrarVenda(v);
        
        if(res)
            limcad.mensagemSucesso();
        else
            limcad.mensagemErro();
    }
    
    //Metodo que deleta uma venda do BD
    public void removerVenda()
    {
        limdel = new LimiteRemocaoVenda();
        int pcod = limdel.getCodigo();
        
        boolean res = deletarVenda(pcod);
        
        if(res)
            limdel.mensagemSucesso();
        else
            limdel.mensagemErro();
    }
    
    //Metodo que atualiza uma venda do BD
    public void atualizarVenda()
    {
        limatt = new LimiteAtualizacaoVenda();
        int pcod = limatt.obterCodigo();
        
        Vendas v = buscaVenda(pcod);
        
        if(v == null)
        {
            limatt.mensagemErro();
        }
        else
        {
            String form[] = new String[4];
            form[0] = ""+v.getCodigo();
            form[1] = ""+v.getData();
            form[2] = ""+v.getValorTotal();
            form[3] = ""+v.getCpfVendedor();
            
            form = limatt.obterDados(form);
            
            //Atualizar campos
            v.setData(converteData(form[1]));
            v.setValorTotal(Double.parseDouble(form[2]));
            v.setCpfVendedor(form[3]);
            boolean res = atualizarVenda(v);
            
            if(res)
                limatt.mensagemSucesso();
            else
                limatt.mensagemErro();
        }
    }
    
    //Metodo que exibe as vendas presentes no BD
    public void exibirVendas()
    {
        //DAO obtem todas as vendas
        ArrayList<Vendas> vendas = listarVendas();
        ArrayList<String[]> lista = new ArrayList<>();
        
        //Converter as vendas em formularios
        for(Vendas v : vendas)
        {
            String st[] = new String[4];
            st[0] = ""+v.getCodigo();
            st[1] = ""+v.getData().getDate()+"/"+v.getData().getMonth()+"/"+v.getData().getYear();
            st[2] = ""+v.getValorTotal();
            st[3] = v.getCpfVendedor();
            
            lista.add(st);
        }
        
        //Passar o formulario para a view exibir
        limvis = new LimiteExibicaoVendas(lista);
    }
    
    public Date converteData(String dataST)
    {
        Date data;
        
        //Quebrar data em 3 partes: p1 = dia, p2 = mes, p3 = ano
        String trechos[] = dataST.split("/");
        
        data = new Date(Integer.parseInt(trechos[2]),Integer.parseInt(trechos[1]),Integer.parseInt(trechos[0]));
        
        return data;
    }
}
