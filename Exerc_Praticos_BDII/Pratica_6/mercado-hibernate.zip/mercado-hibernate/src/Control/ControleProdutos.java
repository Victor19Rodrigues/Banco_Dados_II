package Control;

import Limites.Produto.*;
import java.util.ArrayList;
import model.DAO;
import model.Produtos;
/**
 *
 * @author mateus
 */
public class ControleProdutos extends DAO
{
    private boolean georgeboole;
    private Produtos p1;
    private LimiteCadastroProduto limcad;
    private LimiteRemocaoProduto limdel;
    private LimiteAtualizacaoProduto limatt;
    private LimiteSubMenuProdutos submenu;
    private LimiteExibicaoProdutos limvis;

    public ControleProdutos()
    {
        p1 = null;
        georgeboole = false;
    }
    
    public void menuOpcoes()
    {
        submenu = new LimiteSubMenuProdutos();
        int esc = submenu.getEscolha();
        
        while(esc != 0)
        {
            switch(esc)
            {
                case 1:
                    cadastrarProduto();
                    break;
                case 2:
                    exibirProdutos();
                    break;
                case 3:
                    removerProduto();
                    break;
                case 4:
                    atualizarProduto();
                    break;
            }
            
            esc = submenu.getEscolha();
        }
    }
    
    public void interfaceCadastro()
    {
        limcad = new LimiteCadastroProduto();
    }
    
    public void interfaceRemocao()
    {
        limdel = new LimiteRemocaoProduto();
    }
    
    public void interfaceAtualizacao()
    {
        limatt = new LimiteAtualizacaoProduto();
    }
    
    //Metodo que cadastra um produto no BD
    public void cadastrarProduto()
    {
        interfaceCadastro();
        
        String form[] = limcad.getDados();
        
        //Gerar novo produto com os dados do formulario
        p1 = new Produtos(form[0],Integer.parseInt(form[1]),Float.parseFloat(form[2]));
        
        //Inserir produto no banco
        boolean res = CadastrarProduto(p1);
        
        //Exibir mensagem de resultado ao usuario
        if(res)
            limcad.mensagemSucesso();
        else
            limcad.mensagemErro();
    }
    
    //Metodo que deleta um produto do BD
    public void removerProduto()
    {
        interfaceRemocao();
        
        String form = limdel.getCodigo();
        boolean status =  deletarProduto(Integer.parseInt(form));
        
        if(status)
            limdel.mensagemSucesso();
        else
            limdel.mensagemErro();
    }
    
    //Metodo que atualiza um produto do BD
    public void atualizarProduto()
    {
        Produtos p;
        String form[];
        
        interfaceAtualizacao();
        
        int pcod = limatt.getCodigo();
        
        p = buscaProduto(pcod);
        
        if(p == null)
            limatt.mensagemErro();
        else
        {
            form = new String[4];
            form[0] = ""+p.getCodigo();
            form[1] = p.getNome();
            form[2] = ""+p.getQuantEstoque();
            form[3] = ""+p.getPreco();
            
            form = limatt.obterDadosNovos(form);
            p.setNome(form[1]);
            p.setQuantEstoque(Integer.parseInt(form[2]));
            p.setPreco(Double.parseDouble(form[3]));
            
            boolean status = atualizarProduto(p);
            
            if(status)
                limatt.mensagemSucesso();
            else
            {
                limatt.mensagemErro();
            }
        }
    }
    
    //Metodo que exibe os produtos presentes no BD
    public void exibirProdutos()
    {
        ArrayList<Produtos> lista = listarProdutos();
        ArrayList<String[]> formulario = new ArrayList<>();
        
        for(Produtos p : lista)
        {
            String form[] = new String[4];
            form[0] = ""+p.getCodigo();
            form[1] = p.getNome();
            form[2] = ""+p.getQuantEstoque();
            form[3] = ""+p.getPreco();
            
            formulario.add(form);
        }
        
        limvis = new LimiteExibicaoProdutos(formulario);
                
    }
}
