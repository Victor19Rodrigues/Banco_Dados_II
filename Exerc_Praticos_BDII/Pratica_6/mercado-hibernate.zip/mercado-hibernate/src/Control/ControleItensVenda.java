package Control;

import Limites.ItemVenda.*;
import java.util.ArrayList;
import model.*;
import model.Produtos;

public class ControleItensVenda extends DAO
{
    private LimiteCadastroItemVenda limcad;
    private LimiteAtualizacaoItemVenda limatt;
    private LimiteVisualizacaoItemVenda limvis;
    private LimiteMenuItemVenda limmenu;
    
    public ControleItensVenda()
    {
    }
    
    public void menuOpcoes()
    {
        limmenu = new LimiteMenuItemVenda();
        
        int esc = limmenu.obterEscolha();
        
        while(esc != 0)
        {
            switch(esc)
            {
                case 1:
                    cadastrarItemVenda();
                    break;
                case 2:
                    listarItemVenda();
                    break;
                case 3:
                    atualizarItemVenda();
                    break;
            }
            
            esc = limmenu.obterEscolha();
        }
    }
    
    public void cadastrarItemVenda()
    {
        limcad = new LimiteCadastroItemVenda();
        
        int item[] = limcad.obterDados();
        ItensVendaId id = new ItensVendaId(Short.parseShort(""+item[0]),Short.parseShort(""+item[1]));
        Produtos p = buscaProduto(Short.parseShort(""+item[0]));
        Vendas v = buscaVenda(Short.parseShort(""+item[1]));
        
        if(p == null || v == null)
        {
            limcad.mensagemErro();
        }
        else
        {
            ItensVenda it2 = new ItensVenda(id, p, v,item[2]);
            boolean res = cadastrarItemVenda(it2);
        
            if(res)
                limcad.mensagemSucesso();
            else
                limcad.mensagemErro();
        }
    }
    
    public void listarItemVenda()
    {
        int lista[][];
        ArrayList<ItensVenda> array = visualizarItensVenda();
        
        lista = new int[array.size()][3];
        
        for(int i=0 ; i<array.size() ; i++)
        {
            lista[i][0] = array.get(i).getId().getCodProd();
            lista[i][1] = array.get(i).getId().getCodVenda();
            lista[i][2] = array.get(i).getQuantidade();
        }
        
        limvis = new LimiteVisualizacaoItemVenda(lista,array.size(),3);
    }
    
    public void atualizarItemVenda()
    {
        limatt = new LimiteAtualizacaoItemVenda();
        int vet[] = limatt.obterIdentificador();
        ItensVenda it = null;
        
        ArrayList<ItensVenda> array = visualizarItensVenda();
        
        for(ItensVenda i : array)
        {
            if(i.getId().getCodProd() == Short.parseShort(""+vet[0]) && i.getId().getCodVenda() == Short.parseShort(""+vet[1]))
                it = i;
        }
        
        if(it == null)
        {
            limatt.mensagemErro();
        }
        else
        {
            int qtd = limatt.obterNovaQuantidade();
            it.setQuantidade(qtd);
            
            boolean res = atualizarItemVenda(it);
            
            if(res)
                limatt.mensagemSucesso();
            else
                limatt.mensagemErro();
        }
    }
    
}
