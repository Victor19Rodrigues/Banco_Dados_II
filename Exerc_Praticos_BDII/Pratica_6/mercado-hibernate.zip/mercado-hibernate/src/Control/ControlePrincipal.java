package Control;

import Limites.LimitePrincipal;

/**
 *
 * @author mateus
 */
public class ControlePrincipal
{
    private ControleVendas objCtrlVendas;
    private ControleProdutos objCtrlProdutos;
    private ControleItensVenda objCtrlItens;
    private LimitePrincipal objLimP;
    private int esc = 7;

    public ControlePrincipal()
    {
        objCtrlVendas = new ControleVendas();
        objCtrlItens = new ControleItensVenda();
        objCtrlProdutos = new ControleProdutos();
        objLimP = new LimitePrincipal();
        menu();
    }
    
    public void menu()
    {
        esc = objLimP.getEscolha();
        
        do
        {
            switch(esc)
            {
                case 0:
                    killAll();
                case 1:
                    getCtrlProdutos().menuOpcoes();
                    break;
                case 2:
                    getCtrlVendas().menuOpcoes();
                    break;
                case 3:
                    getCtrlItens().menuOpcoes();
                    break;
            }
            
            esc = objLimP.getEscolha();
        }while(esc != 0);
    }

    public ControleVendas getCtrlVendas()
    {
        return objCtrlVendas;
    }

    public ControleProdutos getCtrlProdutos()
    {
        return objCtrlProdutos;
    }

    public ControleItensVenda getCtrlItens()
    {
        return objCtrlItens;
    }
    
    public void killAll()
    {
        getCtrlVendas().encerrarSessao();
        System.exit(0);
    }
}
